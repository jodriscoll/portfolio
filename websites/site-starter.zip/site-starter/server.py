from startersite import app
app.run(debug=True)
from flask import Flask

import startersite.config

app = Flask(__name__, static_folder='../static')
app.config.from_object(startersite.config)
app.secret_key = app.config['SECRET_KEY']

import startersite.views


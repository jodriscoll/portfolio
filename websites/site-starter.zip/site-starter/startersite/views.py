from startersite import app, ui
from flask import Flask, render_template
from jinja2 import TemplateNotFound

"""
Catch-All Route
first looks for templates in /templates/pages
then looks in /templates
finally renders 404.html with 404 status
Routes requiring custom functionality should be declared above the catch-all
"""
@app.route('/', defaults={'path': 'index'})
@app.route('/<path:path>')
def show_page(path):
    templates = [t.format(path=path) for t in 'pages/{path}.html', '{path}.html']
    context = ui.get_page_context(path)

    # add other template-level parameters to the context object here
    context['company_name'] = 'Silly Starter Sites'

    # render the template
    try:
        return render_template(templates, **context)
    except TemplateNotFound:
        return render_template('404.html', **context), 404

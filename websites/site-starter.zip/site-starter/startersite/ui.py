import cgi
from datetime import date

"""
Get Page Context
setup all variables needed by your templates
"""
def get_page_context(path):
    context = {
        'title': 'Site Title',
        'message': 'This is a message from `ui.get_page_context()`',
        'body_class': get_body_class(path),
        'year': date.today().year
    }
    return context

"""
Get Body Class
returns a string of one or more classes to aid in styling
"""
def get_body_class(path):
    parts = [p for p in path.split('/')]
    if len(parts) > 1:
        parts.append(path.replace('/','-'))
    return cgi.escape(' '.join(parts))

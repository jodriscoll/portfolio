var DIR = process.cwd();
var path = require('path');

var spawn = require('child_process').spawn;
var exec = require('child_process').exec;
var pipe = {stdio: 'inherit'};

function cleanupNginx(pid) {
  exec('kill -TERM ' + pid, function(error, stdout, stderr) {
    if (error) {
      console.log('Couldn’t stop nginx: ' + error);
    }
    console.log(stdout)
    console.log(stderr);
    console.log('Nginx Stopped');
    exec('rm nginx.pid', function(){});
    process.exit()
  });
}

module.exports = function(grunt) {

  require('load-grunt-tasks')(grunt);

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    concat: {
      js: {
        options: {
          separator: "\n\n\n",
        },
        files: {
          'static/js/app.js': ['assets/js/lib/**/*.js', 'assets/js/**/*.js']
        },
      }
    },
    nginx: {
      options: {
        config: './nginx-dev.conf'
      }
    },
    sass: {
      base: {
        options: {
          style: 'expanded'
        },
        files: [{
          expand: true,
          cwd: 'assets',
          src: ['css/**/*.scss','!css/**/_*.scss'],
          dest: 'static',
          ext: '.css'
        }]
      },
      clients: {
        options: {
          style: 'expanded'
        },
        files: [{
          expand: true,
          cwd: 'assets',
          src: ['**/*.scss','!**/_*.scss','!css/**.*'],
          dest: 'static/css',
          ext: '.css'
        }]
      }
    },
    watch: {
      javascript: {
        options: {
          livereload: true
        },
        files: ['assets/**/*.js'],
        tasks: ['concat']
      },
      styles: {
        options: {
          livereload: true
        },
        files: ['assets/**/*.scss'],
        tasks: ['sass']
      },
      templates: {
        options: {
          livereload: true
        },
        files: ['**/*.html'],
        tasks: [] // empty for livereload
      }
    }
  });

  grunt.registerTask('cleanup', function() {
    function byebye() {
      var pid = grunt.file.read(DIR + '/tmp-server/nginx.pid');
      grunt.file.delete(DIR + '/nginx-dev.conf');
      cleanupNginx(pid);
    }
    process.on('SIGINT', byebye);
    process.on('uncaughtException', byebye);
  });

  grunt.registerTask('writeNginxConf', function() {
    grunt.file.mkdir(DIR + '/tmp-server');
    var taskFolder = '/.tasks/nginx/';
    var mimetypes = grunt.file.read(DIR + taskFolder + 'mimetypes');
    var conf = grunt.file.read(DIR + taskFolder + 'conf');
    var data = {
      worker_processes: 2,
      worker_connections: 128,
      mimetypes: mimetypes,
      server_port: grunt.option('port') || 5555,
      server_name: 'startersite',
      server_pid: DIR + '/tmp-server/nginx.pid',
      site_dir: DIR
    };
    var contents = grunt.template.process(conf, {data: data});
    grunt.file.write(DIR + '/nginx-dev.conf', contents);
  });

  grunt.registerTask('nginxServer', [
    'writeNginxConf',
    'flaskServer',
    'nginx:start',
    'cleanup',
    'concat',
    'sass',
    'watch'
  ]);

  grunt.registerTask('flaskServer', 'Run flask server.', function() {
    grunt.log.writeln('Starting Flask development server.');
    spawn('python', ['server.py'], {detatched: true, stdio: 'inherit'});
  });

  grunt.registerTask('flask', [
    'flaskServer',
    'concat',
    'sass',
    'watch'
  ]);

  grunt.registerTask('default', [
    'nginxServer'
  ]);
};

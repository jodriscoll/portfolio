Site Starter
============
*A basic site starter*

## Overview
* Catch-all route for automatically rendering templates
* Grunt-based asset compilation including SASS and jQuery
* Single command to start development: `grunt`
* Nginx or python-only server settings
* Nginx config dynamically created and cleaned-up by Grunt

## CLI
`grunt [--port=5555]` - start nginx server on port (5555) proxy to python
`grunt flask` - start plain-old flask server on port 5000

## Assets
Assets from the `assets/` are automatically compiled to `static/`

### CSS / SCSS
`.scss` files in `assets/css/` are procedded by grunt into plain-old css and
compiled into `static/css/`. Files starting with an underscore (`_`) are
available to `@import`, but are not copied directly to the static folder.

### JS
`.js` files in `assets/js/` are combined into a single `static/js/app.js`.
Files from the lib subdirectory are added before user-created files.


## Setup
### Requirements
* *flask, requests, etc*: `pip install -r requirements.txt`
* *node & npm*: `brew install node`
* *grunt-cli*: `npm install -g grunt-cli`
* *sass*: `gem install sass`

### Init
* clone this repo && cd to the repo
* run `npm install`

### Launch Dev Server (with nginx)
* run `grunt`
* Visit localhost:5555

### Launch Dev Server (without nginx)
* run `grunt flask`
* Visit localhost:5000



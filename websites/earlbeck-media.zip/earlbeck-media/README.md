Earlbeck Media Single Page Template
=====================================
A template for a split layout with two sides. When clicking on a half in the initial view, the layout moves into the respective direction with some transition effects.

Piggybacking off the Codedrops SplitUI (Blueprint: Split Layout)